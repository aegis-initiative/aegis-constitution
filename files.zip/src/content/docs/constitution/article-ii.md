---
title: Article II — Authority Binding
description: Every action must be attributable to a verified, authorized actor — unbound execution is constitutionally invalid
sidebar:
  order: 3
---

:::note
*Renamed from "Authority Verification" in v0.2.0. Verification is one step in the chain — binding is the complete requirement: identity established, authority level confirmed, scope declared, threat posture matched, and every element bound to the audit artifact. The title change reflects the full architectural scope.*
:::

*Every action must be attributable to a verified, authorized actor —
unbound execution is constitutionally invalid.*

---

## Commitment

Every action evaluated by an AEGIS-compliant system must be bound to an identified,
authenticated, authorized actor. The actor must be known before evaluation begins.
The actor's authority must be verified before execution proceeds. The actor's
identity must be recorded in the audit trail regardless of outcome.

Unbound execution — action without attributable authority — is constitutionally
invalid. It cannot be approved. It cannot be escalated. It must be denied.

---

## Foundation

Accountability requires traceability. A governance system that permits anonymous
action cannot assign responsibility when something goes wrong. It cannot reconstruct
what happened, who authorized it, or whether the authorization was valid. The audit
trail becomes forensically worthless.

Authority binding is not authentication alone. It is the complete chain: identity
established, authority level verified, scope declared, threat posture matched, and
every element of that chain bound to the audit artifact produced by the action.

Authority may be delegated. Delegation does not dissolve the chain — it extends it.
Delegated authority must be explicit, scoped, time-bounded, and logged. Implicit
delegation is not delegation. It is assumption. Assumption is not authority.

Authority may be revoked at any time. Revocation takes effect immediately and
invalidates any in-flight execution bound to the revoked authority context.

---

## Enforcement

The governance gateway must authenticate actor identity before processing any
action proposal. Unauthenticated requests must be denied at the gateway boundary
without further evaluation.

The decision engine must verify that the authenticated actor holds authority
appropriate to the requested action at the current threat level. Authority
mismatch produces denial.

Every governance decision — allow, deny, escalate, or require confirmation —
must record the actor identity, authority level, and authority validation result
as non-negotiable audit fields.

Authority context must travel with the action through the full evaluation pipeline
and be bound to the audit artifact at completion.

:::danger
Unbound execution is constitutionally invalid. It cannot be approved, escalated,
or deferred. It must be denied. An action without attributable authority has no
governance basis and no place in a compliant system.
:::

---

## In Practice

The AEGIS architecture defines four authority levels — L0 through L3 — each
corresponding to a class of operational capability and a set of permissible
actions at each threat level. An operator holds L1 authority. A system
administrator holds L2. A governance auditor holds L3. No actor may authorize
actions that exceed their authority level, regardless of the capability grant
they hold. Authority level and capability grant are independent — holding both
is required for execution to proceed.

When authority is delegated — for example, an orchestration system acting on
behalf of a human operator — the delegation chain must be explicit in the
governance record. The delegating actor, the scope of delegation, the time
boundary, and the threat level constraint must all be logged. When the
delegation is revoked or expires, any in-flight execution bound to that
authority context is immediately invalidated. Authority does not linger.

---

## Failure Mode

A system without authority binding can execute actions on behalf of no one in
particular — or anyone who asks. Anonymous execution is not a technical edge
case; it is the default state of ungoverned systems. When an action cannot be
attributed to a verified actor, the governance record is incomplete, the audit
trail is forensically worthless, and accountability collapses. Organizations
that discover a breach in an unbound system cannot answer the most basic
forensic question: who authorized this? They can observe what happened. They
cannot establish why it was permitted, whether the permission was legitimate,
or who is responsible for the outcome.

---

## Relationship to Other Articles

Authority binding depends on Bounded Capability [(Article I)](../article-i) — the actor must
hold a grant for the capability before authority is evaluated. It underpins
Auditability [(Article VII)](../article-vii) — without a verified actor identity, the audit
record cannot establish accountability. And it is directly enforced through
Human Oversight [(Article IV)](../article-iv): escalation pathways require that the human
reviewer's authority level be verified before their decision is accepted into
the governance record.
