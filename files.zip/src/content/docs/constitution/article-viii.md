---
title: Article VIII — Collective Defense
description: Governance at scale requires shared intelligence — AEGIS-compliant systems must be capable of federated governance participation
sidebar:
  order: 9
---

:::note
*Renamed from "Federation Cooperation" in v0.2.0. Cooperation is voluntary — defense is an obligation. A threat observed by one deployment will reach others. Participation in federated governance networks is a constitutional requirement, not an operational preference.*
:::

*Governance at scale requires shared intelligence — AEGIS-compliant systems
must be capable of federated governance participation.*

---

## Commitment

No governed system exists in isolation. A threat observed by one organization
is a threat that will reach others. A circumvention technique discovered in one
deployment will be attempted in every deployment. A novel attack pattern unknown
to a local governance runtime is not a novel attack pattern — it is an attack
in progress, seen elsewhere, unreported here.

AEGIS-compliant systems must be capable of participating in federated governance
networks. The capability is constitutionally required. Its exercise is operationally
determined.

Governance intelligence is a shared resource. Withholding it is a governance failure.

---

## Foundation

Collective defense is an established principle in security operations. Threat
intelligence sharing across organizational boundaries produces faster detection,
faster response, and faster recovery than any organization can achieve alone.
The governance equivalent — sharing circumvention patterns, policy advisories,
and risk signals across AEGIS deployments — extends this principle to the
AI governance domain.

Federation does not require centralized control. The AEGIS Governance Federation
Network operates as a decentralized trust-scored network. Each node retains
full autonomy over its own governance decisions. Federation signals are advisory
intelligence, not directive commands. No federated peer can override a local
governance decision.

Trust in federation is earned, not assumed. Publisher trust scores decay during
inactivity, reflecting the operational reality that stale intelligence is
unreliable intelligence. Security signals and reputation signals are structurally
separated — accumulated reputation cannot soften a security gate.

:::caution
This constraint is architectural, not configurable. Security signals and
reputation signals must be structurally separated. A publisher with a high
reputation score cannot use that reputation to reduce the weight of a security
revocation trigger. Reputation informs autonomy expansion. It does not override
threat detection. These two mechanisms must never be combined into a single score.
:::

---

## Enforcement

Every AEGIS-compliant runtime must implement the GFN-1 federation protocol
at the integration layer — capable of publishing governance signals, consuming
verified signals from trusted peers, and applying federation intelligence to
local risk evaluation.

Federation participation is operationally configurable. Operators may define
which signal categories to publish and consume, which trust thresholds to apply,
and which federation peers to recognize.

Federation signals must be cryptographically signed by the publishing node's
verified identity. Unsigned signals must be rejected.

Local governance authority is never delegated to federation peers. Federation
signals inform local decisions. They do not make them.

---

## In Practice

The GFN-1 protocol defines five signal categories that nodes may publish and
consume: policy updates, circumvention reports, risk signals, governance
attestations, and incident notices. Each signal carries a cryptographic
signature bound to the publisher's Decentralized Identifier (DID), a timestamp
verified within a freshness window, and a replay-prevention token. Signals
that fail any verification check are immediately rejected and logged.

Publisher trust is evaluated against a five-factor composite model: baseline
identity class, historical accuracy, signal quality, audit posture, and
federation reputation. Trust scores decay during inactivity — a publisher
silent for six months has uncertain current posture, and their signals are
weighted accordingly. When a publisher's authority class and computed trust
score produce conflicting ingestion dispositions, the more restrictive applies.
High-trust signals from verified L1 and L2 publishers are ingested automatically.
Low-trust signals enter a quarantine queue for operator review. Reputation
cannot override a security revocation — the two mechanisms are structurally
separated and must never be combined into a single score.

---

## Failure Mode

A governance system that does not share what it knows is a system that has
decided its own operational convenience outweighs the security of the
organizations that will face the same threats next. The failure mode of
non-participation in collective defense is not the isolated compromise of a
single deployment — it is the systematic amplification of adversarial
advantage. An attacker who has successfully circumvented one AEGIS deployment
has a working technique. Without federation, every other deployment discovers
that technique independently, at full cost, on their own timeline. The
constitutional requirement for federation capability is not about information
altruism. It is about the structural reality that governance at scale is only
as strong as the intelligence shared across it.

---

## Relationship to Other Articles

Collective Defense depends on Auditability [(Article VII)](../article-vii) — federation signals
are only credible when they come from nodes whose own governance records are
tamper-evident and verifiable. It depends on Governance Transparency [(Article VI)](../article-vi)
— a node that cannot publish its policy posture cannot earn trust from peers.
And it reinforces Deterministic Enforcement [(Article III)](../article-iii): federation signals
inform local risk evaluation, but local governance decisions are made
deterministically against local policy. Federation advises. Governance decides.
