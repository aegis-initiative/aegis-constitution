---
title: Article IX — Deny by Default
description: In the presence of ambiguity — unclear threat posture, missing scope, unverifiable authority, or unavailable audit — execution does not proceed
sidebar:
  order: 10
---

*In the presence of ambiguity — unclear threat posture, missing scope,
unverifiable authority, or unavailable audit — execution does not proceed.*

---

## Commitment

When governance cannot complete its evaluation, the answer is denial.

Not deferral. Not partial execution. Not best-effort governance. Denial.

Ambiguity is not a condition that governance resolves by proceeding cautiously.
It is a condition that governance resolves by stopping. An incomplete governance
evaluation is a failed governance evaluation. A failed evaluation does not permit
execution.

---

## Foundation

Fail-safe design in safety-critical systems defaults to the safe state under
conditions of uncertainty.[^6] For governance systems, the safe state is denial.
A system that defaults to permission under uncertainty is a system that fails
open. A system that fails open provides no structural guarantee.

The four conditions that trigger denial by default are not arbitrary. They are
the minimum conditions for governance to function:

Threat posture must be known before the appropriate governance rules can be
applied. Unknown threat posture means unknown governance requirements.

Scope must be declared before the boundaries of a governed action can be
evaluated. Missing scope means the action cannot be bounded.

Authority must be verifiable before execution can be attributed. Unverifiable
authority means accountability collapses.

Audit must be available before execution can be completed. Unavailable audit
means the action cannot be recorded. An action that cannot be recorded cannot
be governed.

These are not edge cases. They are foundational preconditions. When any one
of them is absent, governance is not degraded. It is absent.

---

## Enforcement

The governance runtime must evaluate all four preconditions before policy
evaluation begins: threat posture classified, scope declared, authority bound,
audit channel verified.

Failure of any precondition must produce immediate denial. Precondition failures
must not route to escalation — they are not governance decisions requiring human
review. They are governance failures requiring operator investigation.

Precondition failure must be logged with sufficient detail to identify which
condition failed, what was expected, and what was found.

Systems must not implement partial governance — processing some preconditions
while bypassing others based on risk level or action type. All four preconditions
apply to all actions.

:::tip
Precondition failures do not route to escalation. They are not edge cases
requiring human judgment about whether to proceed. They are governance system
failures requiring operator investigation into why a precondition was absent.
The distinction matters: escalation is a governance decision pathway. Precondition
failure is not.
:::

---

## In Practice

The AEGIS governance admission boundary — the first control gate in the AEGIS system
stack — verifies all four preconditions before any action proposal enters policy
evaluation. A request without a classifiable threat posture is denied at the
boundary. A request without declared scope is denied at the boundary. A request
whose actor identity cannot be verified is denied at the boundary. A request
submitted when the audit channel is unavailable is denied at the boundary.

These are not policy decisions. They are precondition failures. They do not
route to the decision engine, they do not trigger escalation workflows, and they
do not require human review — they require operator investigation into why the
precondition was missing. The denial is logged with full context: which condition
failed, what was expected, and what was found. The log entry is itself evidence
that the governance boundary held.

---

## Failure Mode

A system that defaults to permission under uncertainty is not a cautious
governance system — it is an ungoverned system with a cautious self-description.
The failure mode of fail-open design is not a single dramatic incident. It is
the steady accumulation of actions that were permitted because no one explicitly
denied them, under conditions where the governance prerequisites that would have
determined whether they should be permitted were absent. Each individual action
may be low risk. The pattern — systematic operation outside governance boundaries
— is the vulnerability. Deny by Default is not a pessimistic posture. It is the
only posture under which the statement "this action was authorized" means anything.
If authorization is assumed in the absence of denial, authorization means nothing.

---

## Relationship to Other Articles

Deny by Default is the posture from which every other article operates. Bounded
Capability [(Article I)](../article-i) denies undefined capabilities before evaluation begins.
Authority Binding [(Article II)](../article-ii) denies unbound execution at the gateway. Auditability
[(Article VII)](../article-vii) makes unavailable audit a precondition failure — not a logged gap,
but a denial. Escalation Discipline [(Article XI)](../article-xi) applies the same logic to
escalation requests: the absence of required preconditions produces denial, not
partial escalation. Deny by Default is not one article among eleven. It is the
constitutional posture that gives all eleven articles their structural meaning.

---

[^6]: N. G. Leveson, *Engineering a Safer World: Systems Thinking Applied to Safety*, MIT Press, Cambridge, MA, 2011. [Online]. Available: <https://mitpress.mit.edu/9780262533690/engineering-a-safer-world/> See [REFERENCES.md](/references).
