---
title: Principle 8 — Escalation Discipline
description: Escalation requires explicit request, reclassification, approval, and documentation — escalation by inference is prohibited
sidebar:
  order: 9
---

*Escalation requires explicit request, reclassification, approval, and documentation.
Escalation by inference is prohibited.*

---

## Principle

Escalation — the transition to a higher threat level, a broader authority context,
or a more permissive execution environment — is a governed act. It requires all
four of the following:

- **Explicit request** — the escalation must be formally requested, not inferred from context
- **Reclassification** — the threat posture must be formally reclassified to the new level
- **Approval** — a human authority at the appropriate oversight level must approve the escalation
- **Documentation** — the complete escalation event must be recorded in the audit trail

:::danger
Escalation by inference is prohibited without exception. A system that determines,
on its own, that the situation warrants operating at a higher threat level and
proceeds accordingly has self-authorized its own governance boundary expansion.
That is not escalation. It is a constitutional violation.
:::

---

## Meaning

The prohibition on escalation by inference follows directly from the doctrine of
Oversight Before Autonomy. Autonomy is a risk multiplier. Higher threat levels
represent higher autonomy, higher impact, and greater consequences from governance
failure. The oversight requirement at each escalation boundary exists precisely
because the cost of getting it wrong increases at every level. A system that
bypasses that boundary — even with good intentions — has removed the structural
protection that the oversight requirement provides.

Escalation by inference is particularly dangerous because it is operationally
rational. In many situations, an agent that has determined a higher threat level
is warranted is probably correct — the situation probably does warrant it. The
problem is not the agent's judgment about the situation. The problem is that
the agent's judgment is not a governance authority. The governance authority is
the human approver at the appropriate oversight level. Until that authority has
evaluated and approved the escalation, the agent's assessment is a proposal, not
a decision.

The requirement for explicit request, reclassification, and approval is not
bureaucratic overhead. It is the structural mechanism by which human oversight
is exercised at the points where it matters most — before the system operates
at authority levels where its failures are hardest to reverse.

---

## In Practice

The full escalation workflow in a compliant AEGIS implementation is a six-step
governed sequence: explicit request, threat reclassification, authority approval
at the appropriate oversight level, isolation assessment, constraint rebinding,
and state dump with audit preparation. Every step must complete before execution
at the elevated level begins. Partial escalation workflows — those that complete
some steps and skip others — are non-compliant.

At Threat Level 5 (Detached Execution), dual-control authorization is required.
Two independent human authorities must approve before execution proceeds. This
is not a configurable threshold — it is a constitutional requirement. Single-party
escalation approval at Level 5 is constitutionally insufficient regardless of the
authority level of the approving party.

Escalation requests that cannot satisfy their preconditions are denied, not deferred.
If authority is insufficient for the requested level, the escalation is denied.
If threat posture is ambiguous, the escalation is denied. If isolation is infeasible,
the escalation is denied. If the audit channel is unavailable, the escalation is
denied. These denials are applications of Deny by Default, not exceptions to it.

:::note
Escalation denial is logged with the same fidelity as escalation approval.
A pattern of repeated escalation denials for the same agent or the same
task class is a governance signal — it indicates that the agent is regularly
attempting to operate beyond its authorized scope. That pattern is auditable
and should be reviewed.
:::

---

## Failure Mode

A system that escalates by inference is a system that has substituted its own
judgment for the human oversight that the constitution requires. The immediate
failure is the unauthorized expansion of operational authority. The systemic
failure is the normalization of that pattern: a system that has successfully
escalated by inference once has demonstrated to itself that the escalation
pathway can be bypassed. Each subsequent bypass is slightly easier to rationalize.
The practical result is a system that operates with human oversight as an
exception rather than a requirement — consulted when the system determines
consultation is warranted, bypassed when the system determines it is not.

:::caution
The value of the escalation discipline is not in the cases where the agent
would have made the right call anyway. It is in the cases where it would not
have — and in the structural guarantee that even in those cases, a human
authority reviews the decision before irreversible action is taken.
:::

---

## Relationship to Doctrine and Constitution

Escalation Discipline directly operationalizes [Doctrine Article IV — Oversight
Before Autonomy](/doctrine/article-iv): the oversight requirement that scales with
threat level is enforced through the escalation workflow. It grounds both
[Constitutional Article IV — Human Oversight](/constitution/article-iv) and
[Constitutional Article XI — Escalation Discipline](/constitution/article-xi),
which together establish the constitutional requirements for how escalation works
and why it must be governed. And it is an application of [Constitutional Article IX —
Deny by Default](/constitution/article-ix): escalation requests that cannot satisfy
their preconditions produce denial, not partial escalation.
